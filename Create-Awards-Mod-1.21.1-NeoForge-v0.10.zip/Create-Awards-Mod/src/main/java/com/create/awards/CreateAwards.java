package com.create.awards;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

@Mod(CreateAwards.MOD_ID)
public class CreateAwards {
    public static final String MOD_ID = "create_awards";

    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(MOD_ID);
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MOD_ID);
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MOD_ID);

    private static BlockBehaviour.Properties prop() {
        return BlockBehaviour.Properties.of()
                .strength(1.5F)
                .noOcclusion();
    }

    public static final DeferredBlock<Block> PLAQUE_PLAYER_TROPHY =
            BLOCKS.registerSimpleBlock("plaque_player_trophy", prop());
    public static final DeferredBlock<Block> ITEM_TROPHY =
            BLOCKS.registerSimpleBlock("item_trophy", prop());

    public static final DeferredBlock<Block> CREATOR_PLAYBUTTON_100 =
            BLOCKS.registerSimpleBlock("creator_playbutton_100", prop());
    public static final DeferredBlock<Block> CREATOR_PLAYBUTTON_500 =
            BLOCKS.registerSimpleBlock("creator_playbutton_500", prop());
    public static final DeferredBlock<Block> CREATOR_PLAYBUTTON_1K =
            BLOCKS.registerSimpleBlock("creator_playbutton_1k", prop());
    public static final DeferredBlock<Block> CREATOR_PLAYBUTTON_10K =
            BLOCKS.registerSimpleBlock("creator_playbutton_10k", prop());
    public static final DeferredBlock<Block> CREATOR_PLAYBUTTON_100K =
            BLOCKS.registerSimpleBlock("creator_playbutton_100k", prop());

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> TAB =
            TABS.register("create_awards", () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.create_awards"))
                    .icon(() -> ITEMS.get("creator_playbutton_100").get().getDefaultInstance())
                    .withTabsBefore(CreativeModeTabs.COMBAT)
                    .displayItems((params, output) -> {
                        output.accept(ITEMS.get("plaque_player_trophy").get());
                        output.accept(ITEMS.get("item_trophy").get());
                        output.accept(ITEMS.get("creator_playbutton_100").get());
                        output.accept(ITEMS.get("creator_playbutton_500").get());
                        output.accept(ITEMS.get("creator_playbutton_1k").get());
                        output.accept(ITEMS.get("creator_playbutton_10k").get());
                        output.accept(ITEMS.get("creator_playbutton_100k").get());
                    }).build());

    public CreateAwards(IEventBus modBus) {
        BLOCKS.register(modBus);
        ITEMS.register(modBus);
        TABS.register(modBus);

        registerItem("plaque_player_trophy", PLAQUE_PLAYER_TROPHY);
        registerItem("item_trophy", ITEM_TROPHY);
        registerItem("creator_playbutton_100", CREATOR_PLAYBUTTON_100);
        registerItem("creator_playbutton_500", CREATOR_PLAYBUTTON_500);
        registerItem("creator_playbutton_1k", CREATOR_PLAYBUTTON_1K);
        registerItem("creator_playbutton_10k", CREATOR_PLAYBUTTON_10K);
        registerItem("creator_playbutton_100k", CREATOR_PLAYBUTTON_100K);
    }

    private static void registerItem(String id, DeferredBlock<Block> block) {
        ITEMS.register(id, () -> new BlockItem(block.get(), new Item.Properties()));
    }
}
