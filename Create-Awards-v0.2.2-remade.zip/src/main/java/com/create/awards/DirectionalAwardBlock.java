package com.create.awards;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.VoxelShape;

/** Shared decorative award block used by trophies and creator PlayButtons. */
public class DirectionalAwardBlock extends HorizontalDirectionalBlock implements net.minecraft.world.level.block.EntityBlock {
    private static final MapCodec<DirectionalAwardBlock> CODEC = simpleCodec(DirectionalAwardBlock::new);

    protected DirectionalAwardBlock(BlockBehaviour.Properties properties) {
        super(properties);
    }

    @Override
    protected MapCodec<? extends HorizontalDirectionalBlock> codec() {
        return CODEC;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING);
    }

    @Override
    public BlockState getStateForPlacement(net.minecraft.world.item.context.BlockPlaceContext context) {
        // Trophies/PlayButtons stay upright; wall placement faces back toward the player.
        return defaultBlockState().setValue(FACING, context.getHorizontalDirection().getOpposite());
    }

    private static final VoxelShape NORTH = Block.box(1, 0, 0, 15, 16, 2);
    private static final VoxelShape SOUTH = Block.box(1, 0, 14, 15, 16, 16);
    private static final VoxelShape EAST = Block.box(14, 0, 1, 16, 16, 15);
    private static final VoxelShape WEST = Block.box(0, 0, 1, 2, 16, 15);

    @Override
    public VoxelShape getShape(BlockState state, net.minecraft.world.level.BlockGetter level,
                               BlockPos pos, net.minecraft.world.phys.shapes.CollisionContext context) {
        return switch (state.getValue(FACING)) {
            case NORTH -> NORTH;
            case SOUTH -> SOUTH;
            case EAST -> EAST;
            case WEST -> WEST;
            default -> NORTH;
        };
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new PlaqueBlockEntity(pos, state);
    }

    @Override
    public InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos,
                                             Player player, BlockHitResult hit) {
        if (!level.isClientSide && player instanceof ServerPlayer serverPlayer
                && level.getBlockEntity(pos) instanceof PlaqueBlockEntity award) {
            serverPlayer.openMenu(new SimpleMenuProvider(
                    (containerId, inventory, ignored) -> new PlaqueEditMenu(
                            containerId, inventory, pos,
                            award.getAwardTitle(), award.getRecipient(), award.getYear(), award.getDescription()),
                    Component.literal("Engrave Award")
            ), data -> {
                data.writeBlockPos(pos);
                data.writeUtf(award.getAwardTitle(), 40);
                data.writeUtf(award.getRecipient(), 40);
                data.writeUtf(award.getYear(), 12);
                data.writeUtf(award.getDescription(), 60);
            });
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }
}
