package com.create.awards;

import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.network.protocol.Packet;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

public class PlaqueBlockEntity extends BlockEntity {
    private String awardTitle = "Creator Award";
    private String recipient = "";
    private String year = "";
    private String description = "";

    public PlaqueBlockEntity(BlockPos pos, BlockState state) {
        super(CreateAwards.PLAQUE_BLOCK_ENTITY.get(), pos, state);
    }

    public String getAwardTitle() { return awardTitle; }
    public String getRecipient() { return recipient; }
    public String getYear() { return year; }
    public String getDescription() { return description; }

    public void setText(String awardTitle, String recipient, String year, String description) {
        this.awardTitle = limit(awardTitle, 40);
        this.recipient = limit(recipient, 40);
        this.year = limit(year, 12);
        this.description = limit(description, 60);
        setChanged();
        if (level != null) {
            level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
        }
    }

    private static String limit(String value, int max) {
        if (value == null) return "";
        value = value.replace('\n', ' ').replace('\r', ' ').trim();
        return value.length() > max ? value.substring(0, max) : value;
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putString("AwardTitle", awardTitle);
        tag.putString("Recipient", recipient);
        tag.putString("Year", year);
        tag.putString("Description", description);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        awardTitle = tag.getString("AwardTitle");
        recipient = tag.getString("Recipient");
        year = tag.getString("Year");
        description = tag.getString("Description");
    }

    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
        CompoundTag tag = new CompoundTag();
        saveAdditional(tag, registries);
        return tag;
    }

    @Override
    public Packet<net.minecraft.network.protocol.game.ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }
}
