package com.create.awards;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.SimpleMenuProvider;

public class PlaqueBlock extends DirectionalAwardBlock implements net.minecraft.world.level.block.EntityBlock {
    public PlaqueBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties properties) {
        super(properties);
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new PlaqueBlockEntity(pos, state);
    }

    @Override
    public InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        if (!level.isClientSide && player instanceof ServerPlayer serverPlayer
                && level.getBlockEntity(pos) instanceof PlaqueBlockEntity plaque) {
            serverPlayer.openMenu(new SimpleMenuProvider(
                    (containerId, inventory, ignored) -> new PlaqueEditMenu(
                            containerId, inventory, pos,
                            plaque.getAwardTitle(), plaque.getRecipient(), plaque.getYear(), plaque.getDescription()),
                    Component.literal("Edit Creator Plaque")
            ), data -> {
                data.writeBlockPos(pos);
                data.writeUtf(plaque.getAwardTitle(), 40);
                data.writeUtf(plaque.getRecipient(), 40);
                data.writeUtf(plaque.getYear(), 12);
                data.writeUtf(plaque.getDescription(), 60);
            });
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }
}
