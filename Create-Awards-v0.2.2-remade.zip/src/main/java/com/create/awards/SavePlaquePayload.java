package com.create.awards;

import io.netty.buffer.ByteBuf;
import net.minecraft.core.BlockPos;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public record SavePlaquePayload(BlockPos pos, String awardTitle, String recipient, String year, String description)
        implements CustomPacketPayload {
    public static final Type<SavePlaquePayload> TYPE = new Type<>(
            ResourceLocation.fromNamespaceAndPath(CreateAwards.MOD_ID, "save_plaque"));

    public static final StreamCodec<ByteBuf, SavePlaquePayload> STREAM_CODEC = StreamCodec.composite(
            BlockPos.STREAM_CODEC, SavePlaquePayload::pos,
            ByteBufCodecs.STRING_UTF8, SavePlaquePayload::awardTitle,
            ByteBufCodecs.STRING_UTF8, SavePlaquePayload::recipient,
            ByteBufCodecs.STRING_UTF8, SavePlaquePayload::year,
            ByteBufCodecs.STRING_UTF8, SavePlaquePayload::description,
            SavePlaquePayload::new
    );

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(SavePlaquePayload payload, IPayloadContext context) {
        context.enqueueWork(() -> {
            if (!(context.player() instanceof net.minecraft.server.level.ServerPlayer player)) return;
            if (player.level().getBlockEntity(payload.pos()) instanceof PlaqueBlockEntity plaque
                    && player.distanceToSqr(payload.pos().getX() + 0.5, payload.pos().getY() + 0.5, payload.pos().getZ() + 0.5) <= 64.0) {
                plaque.setText(payload.awardTitle(), payload.recipient(), payload.year(), payload.description());
            }
        });
    }
}
