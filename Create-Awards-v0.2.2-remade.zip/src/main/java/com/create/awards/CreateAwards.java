package com.create.awards;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.extensions.IMenuTypeExtension;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

@Mod(CreateAwards.MOD_ID)
public class CreateAwards {
    public static final String MOD_ID = "create_awards";

    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(MOD_ID);
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MOD_ID);
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MOD_ID);
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITY_TYPES =
            DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, MOD_ID);
    public static final DeferredRegister<MenuType<?>> MENUS =
            DeferredRegister.create(Registries.MENU, MOD_ID);

    private static BlockBehaviour.Properties prop() {
        return BlockBehaviour.Properties.of().strength(1.5F).noOcclusion();
    }

    public static final DeferredBlock<PlaqueBlock> PLAQUE_PLAYER_TROPHY =
            BLOCKS.register("plaque_player_trophy", () -> new PlaqueBlock(prop()));
    public static final DeferredBlock<Block> ITEM_TROPHY =
            BLOCKS.register("item_trophy", () -> new DirectionalAwardBlock(prop()));
    public static final DeferredBlock<Block> SILVER_TROPHY =
            BLOCKS.register("silver_trophy", () -> new DirectionalAwardBlock(prop()));
    public static final DeferredBlock<Block> BRONZE_TROPHY =
            BLOCKS.register("bronze_trophy", () -> new DirectionalAwardBlock(prop()));
    public static final DeferredBlock<Block> CREATOR_PLAYBUTTON_100 =
            BLOCKS.register("creator_playbutton_100", () -> new DirectionalAwardBlock(prop()));
    public static final DeferredBlock<Block> CREATOR_PLAYBUTTON_500 =
            BLOCKS.register("creator_playbutton_500", () -> new DirectionalAwardBlock(prop()));
    public static final DeferredBlock<Block> CREATOR_PLAYBUTTON_1K =
            BLOCKS.register("creator_playbutton_1k", () -> new DirectionalAwardBlock(prop()));
    public static final DeferredBlock<Block> CREATOR_PLAYBUTTON_10K =
            BLOCKS.register("creator_playbutton_10k", () -> new DirectionalAwardBlock(prop()));
    public static final DeferredBlock<Block> CREATOR_PLAYBUTTON_100K =
            BLOCKS.register("creator_playbutton_100k", () -> new DirectionalAwardBlock(prop()));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<PlaqueBlockEntity>> PLAQUE_BLOCK_ENTITY =
            BLOCK_ENTITY_TYPES.register("plaque_player_trophy", () -> BlockEntityType.Builder.of(
                    PlaqueBlockEntity::new,
                    PLAQUE_PLAYER_TROPHY.get(), ITEM_TROPHY.get(), SILVER_TROPHY.get(), BRONZE_TROPHY.get(),
                    CREATOR_PLAYBUTTON_100.get(), CREATOR_PLAYBUTTON_500.get(), CREATOR_PLAYBUTTON_1K.get(),
                    CREATOR_PLAYBUTTON_10K.get(), CREATOR_PLAYBUTTON_100K.get()
            ).build(null));

    public static final DeferredHolder<MenuType<?>, MenuType<PlaqueEditMenu>> PLAQUE_EDIT_MENU =
            MENUS.register("plaque_edit", () -> IMenuTypeExtension.create(PlaqueEditMenu::new));

    // Internal icon item used only as the creative-tab icon. It is intentionally not listed in the tab.
    public static final DeferredHolder<Item, Item> CREATE_AWARDS_LOGO =
            ITEMS.register("create_awards_logo", () -> new Item(new Item.Properties()));

    public static final DeferredHolder<Item, Item> PLAQUE_PLAYER_TROPHY_ITEM =
            ITEMS.register("plaque_player_trophy", () -> new BlockItem(PLAQUE_PLAYER_TROPHY.get(), new Item.Properties()));
    public static final DeferredHolder<Item, Item> ITEM_TROPHY_ITEM =
            ITEMS.register("item_trophy", () -> new BlockItem(ITEM_TROPHY.get(), new Item.Properties()));
    public static final DeferredHolder<Item, Item> SILVER_TROPHY_ITEM =
            ITEMS.register("silver_trophy", () -> new BlockItem(SILVER_TROPHY.get(), new Item.Properties()));
    public static final DeferredHolder<Item, Item> BRONZE_TROPHY_ITEM =
            ITEMS.register("bronze_trophy", () -> new BlockItem(BRONZE_TROPHY.get(), new Item.Properties()));
    public static final DeferredHolder<Item, Item> PLAYBUTTON_100_ITEM =
            ITEMS.register("creator_playbutton_100", () -> new BlockItem(CREATOR_PLAYBUTTON_100.get(), new Item.Properties()));
    public static final DeferredHolder<Item, Item> PLAYBUTTON_500_ITEM =
            ITEMS.register("creator_playbutton_500", () -> new BlockItem(CREATOR_PLAYBUTTON_500.get(), new Item.Properties()));
    public static final DeferredHolder<Item, Item> PLAYBUTTON_1K_ITEM =
            ITEMS.register("creator_playbutton_1k", () -> new BlockItem(CREATOR_PLAYBUTTON_1K.get(), new Item.Properties()));
    public static final DeferredHolder<Item, Item> PLAYBUTTON_10K_ITEM =
            ITEMS.register("creator_playbutton_10k", () -> new BlockItem(CREATOR_PLAYBUTTON_10K.get(), new Item.Properties()));
    public static final DeferredHolder<Item, Item> PLAYBUTTON_100K_ITEM =
            ITEMS.register("creator_playbutton_100k", () -> new BlockItem(CREATOR_PLAYBUTTON_100K.get(), new Item.Properties()));

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> TAB =
            TABS.register("create_awards", () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.create_awards"))
                    .icon(() -> CREATE_AWARDS_LOGO.get().getDefaultInstance())
                    .withTabsBefore(CreativeModeTabs.COMBAT)
                    .displayItems((params, output) -> {
                        output.accept(PLAQUE_PLAYER_TROPHY_ITEM.get());
                        output.accept(ITEM_TROPHY_ITEM.get());
                        output.accept(SILVER_TROPHY_ITEM.get());
                        output.accept(BRONZE_TROPHY_ITEM.get());
                        output.accept(PLAYBUTTON_100_ITEM.get());
                        output.accept(PLAYBUTTON_500_ITEM.get());
                        output.accept(PLAYBUTTON_1K_ITEM.get());
                        output.accept(PLAYBUTTON_10K_ITEM.get());
                        output.accept(PLAYBUTTON_100K_ITEM.get());
                    }).build());

    public CreateAwards(IEventBus modBus) {
        BLOCKS.register(modBus);
        ITEMS.register(modBus);
        TABS.register(modBus);
        BLOCK_ENTITY_TYPES.register(modBus);
        MENUS.register(modBus);
        modBus.addListener(CreateAwards::registerPayloads);
    }

    @SubscribeEvent
    public static void registerPayloads(RegisterPayloadHandlersEvent event) {
        event.registrar("1").playToServer(
                SavePlaquePayload.TYPE,
                SavePlaquePayload.STREAM_CODEC,
                SavePlaquePayload::handle
        );
    }
}
