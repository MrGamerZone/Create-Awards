package com.create.awards;

import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;

public class PlaqueEditMenu extends AbstractContainerMenu {
    private final BlockPos pos;
    private final String awardTitle;
    private final String recipient;
    private final String year;
    private final String description;

    public PlaqueEditMenu(int containerId, Inventory inventory, RegistryFriendlyByteBuf data) {
        super(CreateAwards.PLAQUE_EDIT_MENU.get(), containerId);
        this.pos = data.readBlockPos();
        this.awardTitle = data.readUtf(40);
        this.recipient = data.readUtf(40);
        this.year = data.readUtf(12);
        this.description = data.readUtf(60);
    }

    public PlaqueEditMenu(int containerId, Inventory inventory, BlockPos pos,
                          String awardTitle, String recipient, String year, String description) {
        super(CreateAwards.PLAQUE_EDIT_MENU.get(), containerId);
        this.pos = pos;
        this.awardTitle = awardTitle;
        this.recipient = recipient;
        this.year = year;
        this.description = description;
    }

    public BlockPos getPos() { return pos; }
    public String getAwardTitle() { return awardTitle; }
    public String getRecipient() { return recipient; }
    public String getYear() { return year; }
    public String getDescription() { return description; }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        return ItemStack.EMPTY;
    }

    @Override
    public boolean stillValid(Player player) {
        if (player.level().getBlockEntity(pos) instanceof PlaqueBlockEntity) {
            return player.distanceToSqr(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) <= 64.0;
        }
        return false;
    }
}
