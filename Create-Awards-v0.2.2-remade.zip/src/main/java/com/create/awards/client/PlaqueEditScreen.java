package com.create.awards.client;

import com.create.awards.PlaqueEditMenu;
import com.create.awards.SavePlaquePayload;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.network.PacketDistributor;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Inventory;

public class PlaqueEditScreen extends AbstractContainerScreen<PlaqueEditMenu> {
    private EditBox titleBox;
    private EditBox recipientBox;
    private EditBox yearBox;
    private EditBox descriptionBox;

    public PlaqueEditScreen(PlaqueEditMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        this.imageWidth = 300;
        this.imageHeight = 190;
    }

    @Override
    protected void init() {
        super.init();
        int x = leftPos + 24;
        int y = topPos + 38;
        int width = 252;

        titleBox = new EditBox(font, x, y, width, 20, Component.literal("Award Title"));
        titleBox.setMaxLength(40);
        titleBox.setValue(menu.getAwardTitle());
        addRenderableWidget(titleBox);

        recipientBox = new EditBox(font, x, y + 38, width, 20, Component.literal("Recipient"));
        recipientBox.setMaxLength(40);
        recipientBox.setValue(menu.getRecipient());
        addRenderableWidget(recipientBox);

        yearBox = new EditBox(font, x, y + 76, width, 20, Component.literal("Year"));
        yearBox.setMaxLength(12);
        yearBox.setValue(menu.getYear());
        addRenderableWidget(yearBox);

        descriptionBox = new EditBox(font, x, y + 114, width, 20, Component.literal("Description"));
        descriptionBox.setMaxLength(60);
        descriptionBox.setValue(menu.getDescription());
        addRenderableWidget(descriptionBox);

        addRenderableWidget(Button.builder(Component.literal("Save"), button -> save())
                .bounds(leftPos + 24, topPos + 155, 120, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Cancel"), button -> onClose())
                .bounds(leftPos + 156, topPos + 155, 120, 20).build());

        setInitialFocus(titleBox);
    }

    private void save() {
        PacketDistributor.sendToServer(new SavePlaquePayload(
                menu.getPos(),
                titleBox.getValue(),
                recipientBox.getValue(),
                yearBox.getValue(),
                descriptionBox.getValue()
        ));
        onClose();
    }

    @Override
    protected void renderBg(GuiGraphics graphics, float partialTick, int mouseX, int mouseY) {
        graphics.fill(leftPos, topPos, leftPos + imageWidth, topPos + imageHeight, 0xEE161B24);
        graphics.fill(leftPos + 12, topPos + 12, leftPos + imageWidth - 12, topPos + 32, 0xFF2A3240);
        graphics.drawString(font, Component.literal("Creator Plaque Editor"), leftPos + 24, topPos + 19, 0xFFFFFF, false);
        graphics.drawString(font, Component.literal("Award Title"), leftPos + 24, topPos + 29, 0xAAB4C3, false);
        graphics.drawString(font, Component.literal("Recipient"), leftPos + 24, topPos + 67, 0xAAB4C3, false);
        graphics.drawString(font, Component.literal("Year"), leftPos + 24, topPos + 105, 0xAAB4C3, false);
        graphics.drawString(font, Component.literal("Description"), leftPos + 24, topPos + 143, 0xAAB4C3, false);
    }

    @Override
    protected void renderLabels(GuiGraphics graphics, int mouseX, int mouseY) {
        // Labels are drawn manually in renderBg for a compact custom editor.
    }
}
