package com.create.awards.client;

import com.create.awards.PlaqueBlockEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.gui.Font;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import org.joml.Matrix4f;

/** Renders the engraved text stored on plaques, trophies and creator awards. */
public class PlaqueRenderer implements BlockEntityRenderer<PlaqueBlockEntity> {
    private final Font font;

    public PlaqueRenderer(BlockEntityRendererProvider.Context context) {
        this.font = context.getFont();
    }

    @Override
    public void render(PlaqueBlockEntity award, float partialTick, PoseStack stack,
                       MultiBufferSource buffer, int packedLight, int packedOverlay) {
        String title = award.getAwardTitle();
        String recipient = award.getRecipient();
        String year = award.getYear();
        String description = award.getDescription();
        if (title.isEmpty() && recipient.isEmpty() && year.isEmpty() && description.isEmpty()) return;

        Direction facing = award.getBlockState().getValue(HorizontalDirectionalBlock.FACING);
        float yaw = switch (facing) {
            case NORTH -> 0.0F;
            case EAST -> 90.0F;
            case SOUTH -> 180.0F;
            case WEST -> 270.0F;
            default -> 0.0F;
        };

        stack.pushPose();
        stack.translate(0.5, 0.5, 0.5);
        stack.mulPose(Axis.YP.rotationDegrees(yaw));
        // Front of the award model is the negative-Z side.
        stack.translate(0.0, 0.0, -0.54);
        stack.scale(0.0085F, -0.0085F, 0.0085F);

        String[] lines = {title, recipient, year, description};
        int[] colors = {0xFFFFD75A, 0xFFFFFFFF, 0xFFD7DCE5, 0xFFB7C0CE};
        float[] y = {-32.0F, -14.0F, 4.0F, 22.0F};
        for (int i = 0; i < lines.length; i++) {
            if (lines[i].isEmpty()) continue;
            String line = lines[i];
            float width = font.width(line);
            // Keep long engravings inside the visible award instead of spilling below it.
            float scaleDown = Math.min(1.0F, 90.0F / Math.max(1.0F, width));
            stack.pushPose();
            if (scaleDown < 1.0F) stack.scale(scaleDown, scaleDown, scaleDown);
            Matrix4f matrix = stack.last().pose();
            font.drawInBatch(Component.literal(line), -width / 2.0F, y[i], colors[i], true,
                    matrix, buffer, Font.DisplayMode.NORMAL, 0, packedLight);
            stack.popPose();
        }
        stack.popPose();
    }
}
