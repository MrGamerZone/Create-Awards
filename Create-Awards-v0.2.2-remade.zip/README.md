# Create: Awards 0.2.2

Create addon for Minecraft 1.21.1 / NeoForge.

## 0.2.2 fixes and features
- Fixed award model z-fighting on the creator plaque front.
- Added full six-direction placement (walls, floor, ceiling, and horizontal faces).
- Added decorative collision shapes that follow the visible award panel instead of using a full cube.
- Creator plaques, trophies, and creator PlayButtons are all engravable.
- Right-click an award to edit title, recipient, year, and description.
- Fixed the shared save path so engraving data is stored on the award block entity.
- Added a dedicated Create: Awards logo item for the creative-tab icon.
- Creative tab now uses the Create: Awards logo while still displaying all award blocks.
- Added custom gold, silver, and bronze metal textures to avoid color/rendering glitches and make the three trophy finishes visually distinct.

## Build
On Windows with Java 21:

```bat
.\gradlew.bat clean build
```

Output:
`build\libs\Create-Awards-0.2.2.jar`
