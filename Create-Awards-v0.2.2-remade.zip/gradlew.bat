@echo off
setlocal
set "ROOT=%~dp0"
set "GRADLE_VERSION=8.10.2"
set "GRADLE_HOME=%ROOT%\.gradle-bootstrap\gradle-%GRADLE_VERSION%"
set "GRADLE_ZIP=%ROOT%\.gradle-bootstrap\gradle-%GRADLE_VERSION%-bin.zip"
if exist "%GRADLE_HOME%\bin\gradle.bat" goto run
if not exist "%ROOT%\.gradle-bootstrap" mkdir "%ROOT%\.gradle-bootstrap"
echo Gradle %GRADLE_VERSION% is not installed for this project. Downloading it...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%GRADLE_ZIP%'"
if errorlevel 1 (
  echo Failed to download Gradle. Check your internet connection.
  exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -LiteralPath '%GRADLE_ZIP%' -DestinationPath '%ROOT%\.gradle-bootstrap' -Force"
if errorlevel 1 (
  echo Failed to extract Gradle.
  exit /b 1
)
:run
call "%GRADLE_HOME%\bin\gradle.bat" %*
exit /b %ERRORLEVEL%
